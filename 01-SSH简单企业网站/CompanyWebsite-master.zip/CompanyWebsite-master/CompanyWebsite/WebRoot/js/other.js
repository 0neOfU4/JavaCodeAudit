
$(function(){
	$('#myCarousel').carousel('cycle');
});