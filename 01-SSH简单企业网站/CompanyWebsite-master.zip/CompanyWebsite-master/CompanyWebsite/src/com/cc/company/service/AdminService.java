package com.cc.company.service;

import com.cc.company.domain.Admin;

public interface AdminService {

	public Admin getAdmin(Admin admin);

	public Admin updateAdminPwd(Admin admin);

}
