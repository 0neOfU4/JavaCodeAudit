package com.cc.company.dao;

import com.cc.company.domain.Admin;

public interface AdminDao {

	public Admin getAdmin(Admin admin);

	public Admin updateAdminPwd(Admin admin);

}
