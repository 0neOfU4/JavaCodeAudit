package com.tugos.dst.admin.entity;


import lombok.Data;

@Data
public class User {

    private String username;

    private String password;

    private String nickname;

    private String picture;

}
