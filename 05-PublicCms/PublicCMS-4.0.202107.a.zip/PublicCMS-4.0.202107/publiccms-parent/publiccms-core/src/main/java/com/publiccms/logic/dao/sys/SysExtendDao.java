package com.publiccms.logic.dao.sys;

import com.publiccms.entities.sys.SysExtend;

// Generated 2016-3-2 13:39:44 by com.publiccms.common.source.SourceGenerator

import org.springframework.stereotype.Repository;

import com.publiccms.common.base.BaseDao;

/**
 *
 * SysExtendDao
 * 
 */
@Repository
public class SysExtendDao extends BaseDao<SysExtend> {

    @Override
    protected SysExtend init(SysExtend entity) {
        return entity;
    }

}