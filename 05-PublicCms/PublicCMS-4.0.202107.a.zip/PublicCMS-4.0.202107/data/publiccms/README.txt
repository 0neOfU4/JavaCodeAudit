﻿backup
    删除文件备份,由系统自动创建

dict
    自定义分词文件目录

history
   文件修改历史,由系统自动创建

indexes
    全文搜索索引文件目录,由系统自动创建

task
    任务计划脚本目录

template
    站点模板目录

web
    静态文件目录

install.lock
    安装锁,由系统自动创建

database.properties
    数据库配置,由系统自动创建,其中jdbc.encryptPassword为加密数据库密码优先级高于jdbc.password
